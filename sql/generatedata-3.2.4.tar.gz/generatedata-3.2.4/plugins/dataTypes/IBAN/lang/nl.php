<?php

$L = array();

$L["DATA_TYPE"] = array(
    "NAME" => "Bankrekening Nums`",
    "DESC" => "Genereert IBAN (International Bank Account Number)."
);

$L["help_1"] = "De gegenereerde IBAN heeft een geldige checksum, landcode en de lengte en de BIC is op de juiste plaats.";
$L["help_2"] = "Het nummer is zeer onwaarschijnlijk om echt <i>geldig</i> tho zijn, aangezien er meestal een heleboel controles te doen, tegen specifieke landen.";
