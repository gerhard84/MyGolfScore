<?php

$L = array();

$L["DATA_TYPE"] = array(
    "NAME" => "Nums de compte bancaire (IBAN)",
    "DESC" => "Génère IBAN (International Bank Account Number)."
);

$L["help_1"] = "L'IBAN a généré une somme de contrôle valide, countrycode la longueur et le BIC est au bon endroit.";
$L["help_2"] = "Le nombre est hautement improbable qu'il soit vraiment tho <i>valide</i>, car il ya généralement un tas de vérifications à faire qui sont spécifiques des pays.";
