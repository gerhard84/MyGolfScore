<?php

$L = array();

$L["DATA_TYPE"] = array(
    "NAME" => "Teléfono / Fax, Regional",
    "DESC" => "Este tipo de datos trata de generar un número de teléfono en un formato adecuado para la fila de datos. Si se encuentra con un país desconocido, genera un número de teléfono predeterminado en el formato (xxx) xxx-xxxx."
);
