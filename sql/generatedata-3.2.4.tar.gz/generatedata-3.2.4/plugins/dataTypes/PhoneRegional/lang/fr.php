<?php

$L = array();

$L["DATA_TYPE"] = array(
    "NAME" => "Téléphone / Fax, Régional",
    "DESC" => "Ce type de données tente de générer un numéro de téléphone dans un format approprié pour la ligne de données. Si elle rencontre un pays inconnu, il génère un numéro de téléphone par défaut dans le format (xxx) xxx-xxxx."
);
