<?php

$L = array();

$L["DATA_TYPE"] = array(
    "NAME" => "Samengesteld",
    "DESC" => "De Composite gegevenstype kunt u combineren de gegevens van een andere rij of rijen, en te manipuleren, wijzigen, combineren de informatie en meer. De inhoud moet worden opgenomen in de Smarty template taal."
);

$L["Composite_division"] = "divisie";
$L["Composite_help_2"] = "Om de waarde van een rij uit te voeren, gewoon gebruik maken van de tijdelijke aanduidingen <b>{\$ROW1}</b>, <b>{\$ROW2}</b>, enz. U kunt niet verwijzen naar de huidige rij - dat zou een smeltpunt de server en / of maak het universum imploderen.";
$L["Composite_help_3"] = "Hier zijn een paar voorbeelden:";
$L["Composite_help_4"] = "Geef een waarde van rij 6: <b>{\$ROW6}</b>";
$L["Composite_help_5"] = "Ervan uitgaande dat rij 1 en rij 2 bevatten willekeurige getallen, worden de volgende voorbeelden van een aantal eenvoudige wiskunde:";
$L["Composite_help_6"] = "Als rij 1 bevat het nummer 5, weer te geven \"N / A\", anders gewoon weer het nummer.";
$L["Composite_help_7"] = "Raadpleeg de <a href=\"http://www.smarty.net/\">Smarty website</a> voor meer informatie over de syntaxis.";
$L["Composite_multiplication"] = "vermenigvuldiging";
$L["Composite_na"] = "N / A";
$L["Composite_subtraction"] = "aftrekking";
