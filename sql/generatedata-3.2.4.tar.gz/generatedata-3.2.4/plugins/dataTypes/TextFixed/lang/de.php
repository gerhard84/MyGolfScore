<?php

$L = array();
$L["DATA_TYPE"] = array(
    "NAME" => "Feste Anzahl der Worte",
    "DESC" => "Diese Option erzeugt eine feste Anzahl von zufälligen Wörtern, von der Norm Lorem ipsum lateinischen Text."
);

$L["TextFixed_generate"] = "Erzeugen";
$L["TextFixed_help"] = "Diese Option erzeugt eine feste Anzahl von zufälligen Wörtern, von der Norm <a href=\"http://en.wikipedia.org/wiki/Lorem_ipsum\" target=\"_blank\">Lorem ipsum</a> lateinischen Text.";
$L["TextFixed_words"] = "Text";
$L["incomplete_fields"] = "Bitte geben Sie die Anzahl der Wörter, die Sie für alle Feste Wortzahl Felder erzeugen. Siehe Zeilen:";
