<?php

$L = array();
$L["DATA_TYPE"] = array(
    "NAME" => "Fixed Number of Words",
    "DESC" => "This option generates a fixed number of random words, pulled from the standard lorem ipsum latin text."
);

$L["TextFixed_generate"] = "Generate";
$L["TextFixed_help"] = "This option generates a fixed number of random words, pulled from the standard <a href=&quot;http://en.wikipedia.org/wiki/Lorem_ipsum&quot; target=&quot;_blank&quot;>lorem ipsum</a> latin text.";
$L["TextFixed_words"] = "words";
$L["incomplete_fields"] = "Please enter the number of words you want to generate for all Fixed Number of Words fields. See rows: ";
