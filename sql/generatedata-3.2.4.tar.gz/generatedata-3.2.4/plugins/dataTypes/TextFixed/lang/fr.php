<?php

$L = array();
$L["DATA_TYPE"] = array(
    "NAME" => "Texte - Longueur Fixe",
    "DESC" => "Cette option génère un nombre fixe de mots aléatoires lorem ipsum (faux texte latin)."
);

$L["TextFixed_generate"] = "Générer";
$L["TextFixed_help"] = "Cette option génère un nombre fixe de mots aléatoires <a href=\"http://en.wikipedia.org/wiki/Lorem_ipsum\" target=\"_blank\">lorem ipsum</a> (faux texte latin).";
$L["TextFixed_name"] = "Nombre fixe de mots";
$L["TextFixed_words"] = "mots";
$L["incomplete_fields"] = "Entrez le nombre de mots que vous souhaitez générer. Voir les lignes:";
