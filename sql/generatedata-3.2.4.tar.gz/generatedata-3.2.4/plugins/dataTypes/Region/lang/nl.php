<?php

$L = array();
$L["DATA_TYPE"] = array(
    "NAME" => "Regio",
    "DESC" => "Genereert willekeurige Canadese provincies, staten, gebieden of provincies, op basis van de opties die u selecteert."
);

$L["full"] = "Volledig";
$L["help_text"] = "De <b>Volledige naam</b> en <b>Afkorting</b> sub-opties bepalen of de uitgang zal de volledige string (bijv. \"British Columbia\") of de afkorting (bijv. \"BC\") bevatten. Voor het Verenigd Koninkrijk provincies, de afkorting is van de standaard 3-tekens Chapman code.";
$L["short"] = "Kort";
$L["no_countries_selected"] = "Geen landen geselecteerd.";
