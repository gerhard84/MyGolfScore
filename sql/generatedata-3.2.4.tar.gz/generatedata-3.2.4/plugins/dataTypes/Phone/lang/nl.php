<?php

$L = array();

$L["DATA_TYPE"] = array(
    "NAME" => "Telefoon / Fax",
    "DESC" => "Genereert een willekeurig telefoonnummer / faxnummer in een verscheidenheid van formaten voor verschillende landen / regio's."
);

$L["australia"] = "Australië";
$L["different_formats"] = "Verschillende formaten";
$L["example_1"] = "Canada (1)";
$L["example_2"] = "Canada (2)";
$L["france"] = "Frankrijk";
$L["germany"] = "Duitsland";
$L["help_text1"] = "Wat tekst die u invoert in het opties tekstveld wordt gebruikt om telefoonnummers te genereren. Hoofdstad <b>X</b> 's zal worden omgezet naar een willekeurig getal tussen 1 en 9; kleine letters <b>x</b>' s zal worden omgezet naar een willekeurig getal tussen 0 en 9.";
$L["help_text2"] = "Selecteer een van de waarden in het voorbeeld dropdown voor een aantal ideeën. Vergeet niet: iets anders dan de <b>X</b> en <b>x</b> karakter overblijven onbekeerd.";
$L["help_text3"] = "Zoals met veel van de andere soorten gegevens, het genereren van telefoonnummers in meerdere formaat ze te scheiden met een pijp | karakter.";
$L["incomplete_fields"] = "The Phone / Fax gegevenstype dient te beschikken over het formaat ingevoerd in het Opties tekstveld. Please fix de volgende rijen:";
$L["japan"] = "Japan";
$L["uk"] = "UK";
