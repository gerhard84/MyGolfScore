<?php

$L = array();

$L["DATA_TYPE"] = array(
    "NAME" => "CVV",
    "DESC" => "Genera un número de tarjeta de crédito CVV azar 111-999."
);
