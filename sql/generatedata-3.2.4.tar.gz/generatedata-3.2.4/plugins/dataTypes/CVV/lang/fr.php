<?php

$L = array();

$L["DATA_TYPE"] = array(
    "NAME" => "CVV",
    "DESC" => "Génère un nombre aléatoire de CVV de la carte de crédit de 111 à 999."
);
