<?php

$L = array();

$L["DATA_TYPE"] = array(
    "NAME" => "CVV",
    "DESC" => "Generates a random credit card CVV number from 111 to 999."
);
