<?php

$L = array();

$L["DATA_TYPE"] = array(
    "NAME" => "Standardabweichung",
    "DESC" => "Erzeugt ZufallsnormalverteiltenWerten mit einem kundengerechten Mittelwert und Standardabweichung ."
);

$L["incomplete_fields"] = "Der Mittelwert und Sigma Felder sind für alle Normal Distribution Zeilen erforderlich. Bitte beheben Sie die folgenden Zeilen:";
$L["mean"] = "Bedeuten";
