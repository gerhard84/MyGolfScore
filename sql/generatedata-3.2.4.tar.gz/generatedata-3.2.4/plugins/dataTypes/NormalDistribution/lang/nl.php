<?php

$L = array();

$L["DATA_TYPE"] = array(
    "NAME" => "Normaal Distributie",
    "DESC" => "Toevalsgetallen normaal waarden met een aanpasbare gemiddelde en de standaarddeviatie ."
);

$L["incomplete_fields"] = "Les champs moyens et Sigma sont nécessaires pour toutes les lignes de distribution normale. S'il vous plaît corriger les lignes suivantes:";
$L["mean"] = "Signifier";
$L["standard_deviation"] = "Écart type";
