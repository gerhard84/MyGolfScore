<?php

$L = array();

$L["DATA_TYPE"] = array(
    "NAME" => "Entreprise",
    "DESC" => "Ce type de données génère un nom d'entreprise aléatoire, composé d'un mot Lorem ipsum et un suffixe, comme Dolor Inc, ou Convallis limitée."
);
