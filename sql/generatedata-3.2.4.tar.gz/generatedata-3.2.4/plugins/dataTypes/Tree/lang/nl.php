<?php

$L = array();
$L["DATA_TYPE"] = array(
    "NAME" => "Boom (ouder rij ID)",
    "DESC" => "Dit gegevenstype kunt u het genereren van boom-achtige data waarin elke rij is een kind van een andere rij - met uitzondering van de eerste rij, dat is de stam van de boom."
);

$L["auto_increment_row_num"] = "Auto-increment rijnummer:";
$L["help_1"] = "Dit gegevenstype kunt u het genereren van boom-achtige data waarin elke rij is een kind van een andere rij - met uitzondering van de eerste rij, dat is de stam van de boom. Dit gegevenstype moet worden gebruikt in combinatie met de Auto-Increment gegevenstype: die ervoor zorgt dat elke rij een unieke numerieke waarde, die dit gegevenstype gebruikt om te verwijzen naar de bovenliggende rijen.";
$L["help_2"] = "De opties kunt u aangeven welke van uw formulier velden is de juiste auto-increment veld en het maximale aantal kinderen een knooppunt kan hebben.";
$L["invalid_fields"] = "Gelieve enkel cijfers voor de Tree Data Type veld instellingen. Please fix rijen:";
$L["invalid_parent"] = "[Ongeldig ouder]";
$L["max_num_sibling_nodes"] = "Max aantal broers en zussen knooppunten:";
