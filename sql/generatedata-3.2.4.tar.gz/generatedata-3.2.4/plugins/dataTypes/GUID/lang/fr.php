<?php

$L = array();

$L["DATA_TYPE"] = array(
    "NAME" => "GUID",
    "DESC" => "Génère un GUID (identificateur global unique) unique aléatoire de la forme: XXXXXXXX-XXXX-XXXX-XXXX-XXXXXXXXXXXX, où X est un chiffre hexadécimal)."
);

