<?php

$L = array();

$L["DATA_TYPE"] = array(
    "NAME" => "GUID",
    "DESC" => "Generiert einen eindeutigen, zufälligen GUID (Globally Unique Identifier) ​​der Form: XXXXXXXX-XXXX-XXXX-XXXX-XXXXXXXXXXXX, wobei X eine beliebige Hexadezimalzahl)."
);

