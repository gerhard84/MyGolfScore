<?php

$L = array();

$L["DATA_TYPE"] = array(
    "NAME" => "Alphanumerisch",
    "DESC" => "Erzeugt eine benutzerdefinierte zufällige alphanumerische Zeichenfolge oder Länge oder Format , durch Platzhalter Zeichen definiert."
);

$L["example_CanPostalCode"] = "(Can. PLZ)";
$L["example_Password"] = "(Password)";
$L["example_USZipCode"] = "(US Postleitzahl)";
$L["help_1"] = "Ein Groß-<b>L</b> etter.";
$L["help_10"] = "Jede Anzahl, 1-9.";
$L["help_11"] = "Ein Konsonant (obere oder untere).";
$L["help_12"] = "Ein <b>H</b> exidecimal Nummer (0-F)";
$L["help_2"] = "Ein Groß-<b>V</b>owel.";
$L["help_3"] = "Ein Kleinbuchstaben <b>l</b> etter.";
$L["help_4"] = "Ein Kleinbuchstaben <b>v</b> owel.";
$L["help_5"] = "Ein Brief (oben oder unten).";
$L["help_6"] = "Ein Vokal (obere oder untere).";
$L["help_7"] = "Ein Groß-<b>C</b> onsonant.";
$L["help_8"] = "Jede Zahl, 0-9.";
$L["help_9"] = "Ein Kleinbuchstaben <b>c</b> onsonant.";
$L["help_intro"] = "Dieser Datentyp können Sie zufällige alphanumerische Zeichenfolgen. Die folgende Tabelle enthält die Zeichenlegende für dieses Feld. Alle anderen Zeichen, die Sie in diesem Feld erscheint unescaped.";
$L["incomplete_fields"] = "Alphanumerische Felder müssen Sie das Format, in dem Optionen Textfeld eingeben. Bitte beheben Sie die folgenden Zeilen:";

