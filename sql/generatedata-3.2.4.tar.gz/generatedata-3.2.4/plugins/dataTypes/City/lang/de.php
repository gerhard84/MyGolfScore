<?php

$L = array();
$L["DATA_TYPE"] = array(
    "NAME" => "City",
    "DESC" => "Zeigt ein zufälliges Stadt , oder wenn Daten verfügbar sind , zeigt eine Stadt für das entsprechende Land / Region."
);
