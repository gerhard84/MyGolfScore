<?php

$L = array();

$L["DATA_TYPE"] = array(
    "NAME" => "Stad",
    "DESC" => "Geeft een willekeurige stad , of indien gegevens beschikbaar zijn , wordt een stad voor de juiste land / regio ."
);
