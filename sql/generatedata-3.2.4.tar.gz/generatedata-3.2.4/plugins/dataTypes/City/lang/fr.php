<?php

$L = array();

$L["DATA_TYPE"] = array(
    "NAME" => "Ville",
    "DESC" => "Affiche une ville au hasard , ou si les données sont disponibles , affiche une ville pour le pays / région appropriée ."
);
