<?php

$L = array();
$L["DATA_TYPE"] = array(
    "NAME" => "Track 2",
    "DESC" => "Piste 2 contient le compte du titulaire de carte, code PIN crypté, ainsi que d'autres données discrétionnaires. La carte de crédit peut être de tout type (Visa, Mastercard, etc.)"
);
