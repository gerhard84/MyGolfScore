<?php

$L = array();
$L["DATA_TYPE"] = array(
    "NAME" => "Track 2",
    "DESC" => "Track 2 bevat rekening van de kaarthouder, versleutelde PIN, plus andere discretionaire gegevens. De creditcard kan van elk type zijn (Visa, Mastercard, etc)."
);
