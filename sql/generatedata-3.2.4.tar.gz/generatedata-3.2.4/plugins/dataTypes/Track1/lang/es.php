<?php

$L = array();
$L["DATA_TYPE"] = array(
    "NAME" => "Track 1",
    "DESC" => "Track 1 contiene el nombre del titular de la tarjeta, así como el número de cuenta y otros datos discrecionales. La tarjeta de crédito puede ser de cualquier tipo (Visa, Mastercard, etc)."
);
