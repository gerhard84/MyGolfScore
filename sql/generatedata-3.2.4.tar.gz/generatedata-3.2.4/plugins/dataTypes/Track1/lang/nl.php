<?php

$L = array();
$L["DATA_TYPE"] = array(
    "NAME" => "Track 1",
    "DESC" => "Track 1 bevat de naam van de kaarthouder en rekeningnummer en andere discretionaire gegevens. De creditcard kan van elk type zijn (Visa, Mastercard, etc)."
);
