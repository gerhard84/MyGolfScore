<?php

$L = array();
$L["DATA_TYPE"] = array(
    "NAME" => "Straat en huisnummer",
    "DESC" => "Genereert willekeurige adressen ."
);

$L["ap_num"] = "Ap #";
$L["po_box"] = "PO Box";
$L["street_types"] = "St., St., straat, weg, Rd., Rd., Ave, Av., Avenue";
