<?php

$L = array();

$L["DATA_TYPE"] = array(
    "NAME" => "Code Postal",
    "DESC" => "Génère un code postal aléatoire. Pour un meilleur contrôle, utilisez le type de données Alphanumérique."
);
