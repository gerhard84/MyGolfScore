<?php

$L = array();

$L["DATA_TYPE"] = array(
    "NAME" => "PIN",
    "DESC" => "Genera un número PIN de la tarjeta de crédito azar de 1111 a 9999."
);
