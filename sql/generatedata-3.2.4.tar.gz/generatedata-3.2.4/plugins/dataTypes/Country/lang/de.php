<?php

$L = array();

$L["DATA_TYPE"] = array(
    "NAME" => "Land",
    "DESC" => "Erzeugt eine Zufallsländernamenmit der Option, um die Teilmenge , um diese Länder über die Schnittstelle eingegeben begrenzen."
);

$L["limit_results"] = "Beschränken Ländern zu den oben ausgewählten";
