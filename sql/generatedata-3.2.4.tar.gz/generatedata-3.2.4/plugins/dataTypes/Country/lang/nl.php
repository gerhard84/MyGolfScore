<?php

$L = array();

$L["DATA_TYPE"] = array(
    "NAME" => "Land",
    "DESC" => "Genereert een willekeurig land naam , met de optie om de subset beperken tot die landen ingevoerd via de interface ."
);

$L["limit_results"] = "Beperk landen met de hierboven geselecteerde";
