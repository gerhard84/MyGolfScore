<?php

$L = array();

$L["DATA_TYPE"] = array(
    "NAME" => "Rango numérico",
    "DESC" => "Este tipo genera un número aleatorio entre los valores que especifiques. Ambos campos permite introducir números negativos."
);

$L["and"] = "y";
$L["between"] = "Entre";
$L["incomplete_fields"] = "Por favor, introduce el rango numérico (números inferior y superior) para las siguientes filas:";
