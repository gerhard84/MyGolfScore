<?php

$L = array();
$L["EXPORT_TYPE_NAME"] = "CSV";

$L["delimiter_chars"] = "Caractère de séparation";
$L["eol_char"] = "Caractère de fin de ligne";
$L["validation_no_delimiter"] = "Entrez un caractère de séparation pour le type d'exportation CSV.";
